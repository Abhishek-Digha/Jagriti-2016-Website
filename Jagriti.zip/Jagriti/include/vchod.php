<div class="container-fluid">
  <div class="row">
  <div class="col-sm-4" style="background-color:lavender;">
   		<div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>About Jagriti</b></h3>
	      </div>
	      <div style="text-align: center;">
	      <b style="color: #ff751a;">Jagriti (Vashudhav Kutumbkam)</b>
	      <p>The meaning of Vashudhav Kutumbkam is " The whole world is our family" and Jagriti is the name and Identity of our family.</p>
	      <p>It is celebrated since 2011 and till then every year we celebrate this fest on the ocassion of Hindi Diwas</p>
	      <p>So in continuation of this again in this year on 15 oct 2016 we are going to celebrate it with our full devotion to contunue in future.</p>
	       </div>
    </div>
    </div>
  <div class="col-sm-4" style="background-color:lavender;">
	  <div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>Vice Chancellor P.U</b></h3>
	      </div>
          <div class="panel-body">
              <td><img src="images/vc.png" width="100%" height="100%" ></td><br><br>
	             <div class="list-group">
		             <a class="list-group-item active" href="http://www.pondiuni.edu.in/vc-message/vice-chancellor-officiating">
		             <td><b>Prof.(Dr.)Anisha Basir Khan</b></td>
		             <td>(Officiating) </td>
		             </a>
	             </div>
           </div>
      </div>
  </div>
  <div class="col-sm-4" style="background-color:lavender;">
	  <div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>Cultural Co-ordinator</b></h3>
	      </div>
          <div class="panel-body">
              <td><img src="images/nalinee.jpg" width="100%" height="100%" ></td><br><br>
	             <div class="list-group">
		             <a class="list-group-item active" href="http://www.pondiuni.edu.in/profile/dr-nalini-j-thampi">
		             <td><b>Dr. Nalini J. Thampi</b><br></td>
		             <td>Proff. & H.O.D (French Dept.)</td>
		             </a>
	             </div>
           </div>
      </div>
  </div>
      
  </div>
</div>
