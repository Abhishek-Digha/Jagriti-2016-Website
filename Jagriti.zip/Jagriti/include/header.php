<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="shortcut icon" type="images/include/icon.ico" href="favicon.ico" />
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <meta charset="utf-8">
        <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500"/>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
		<link rel="stylesheet" type="text/css" href="css/w3.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href="css/site.css" rel="stylesheet" type="text/css" />
            
  	</head>
	<body style="background: url(images/diya.jpg);">
	<div style="width:70%; margin: auto;">