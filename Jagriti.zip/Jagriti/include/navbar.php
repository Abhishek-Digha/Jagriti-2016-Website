<!--<nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="97">
        <div class="container">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
          </div>

          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li class="active"><a href="#">Home</a></li>
                <li><a href="#">Faculty</a></li>
                <li><a href="#">Student</a></li>
                <li><a href="#">Courses</a></li>
                <li><a href="#">Notice Board</a></li>
                <li><a href="#">Contact Us</a></li>
                </ul>
          </div>
        </div>
    </nav>
    <div class="container"></div>
    -->

    <ul class="nav nav-tabs" style="background-color:#ecd9c6;" >
    <li class="active"><a href="#home" data-toggle="tab" aria-expanded="true">Home</a></li>
    <li><a href="#gallery" data-toggle="tab" aria-expanded="true">Gallery</a></li> 
    <li class=""><a href="#notice" data-toggle="tab" aria-expanded="true">Notice Board</a></li>
    <li class=""><a href="#contact" data-toggle="tab" aria-expanded="true">Contact Us</a></li>
</ul>
<div id="myTabContent" class="tab-content">
    <div class="tab-pane fade active in" id="home" >
       <?php include('include/gallery.php'); ?>
       <?php include('include/about.php'); ?>
       <?php include('include/vchod.php'); ?> 
       <?php include('include/footer.php'); ?> 
      </div>
    <div class="tab-pane fade" id="contact">
      <?php include('include/faculty.php'); ?>
      <?php include('include/footer.php'); ?>
    </div>
    <div class="tab-pane fade" id="notice">
      <?php include('include/mca.php'); ?> 
      <?php include('include/footer.php'); ?> 
    </div>
    <div class="tab-pane fade" id="contact">
      <?php include('include/mtech.php'); ?> 
      <?php include('include/footer.php'); ?> 
    </div>
    <div class="tab-pane fade" id="msc">
      <?php include('include/msc.php'); ?> 
      <?php include('include/footer.php'); ?> 
    </div>
    <div class="tab-pane fade" id="phd">
      <?php include('include/phd.php'); ?> 
      <?php include('include/footer.php'); ?> 
    </div>
  <div class="tab-pane fade" id="dropdown2">
    <p>Trust fund seitan letterpress, keytar raw denim keffiyeh etsy art party before they sold out master cleanse gluten-free squid scenester freegan cosby sweater. Fanny pack portland seitan DIY, art party locavore wolf cliche high life echo park Austin. Cred vinyl keffiyeh DIY salvia PBR, banh mi before they sold out farm-to-table VHS viral locavore cosby sweater.</p>
  </div>
</div>