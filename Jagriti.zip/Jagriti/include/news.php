<div class="w3-content w3-section" id="pause" >
  <div class="mySlides">Jagriti 2nd Audition will held on 08/10/2016</div>
  <div class="mySlides">jagriti 2016 will be celebrated on 15 oct 2016 venue: J N Auditorium</div>
  <div class="mySlides">Play on Women empowerment by Jagriti Team </div>
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); // Change image every 2 seconds
}
</script>
