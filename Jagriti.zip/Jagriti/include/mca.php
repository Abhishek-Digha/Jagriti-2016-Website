
 <div class="panel panel-primary" >
			  <div class="panel-heading" style="background-color: #4db8ff;">
			        <h3 class="panel-title" style="text-align: center;"><b>LATEST UPDATES JAGRITI 2016</b></h3>
			  </div>
			  <div class="panel-body">
			        Jagriti 2016 will be held on 15 oct 2016 at J.N Auditorium (Pondicherry University)
			  </div>
			  <div class="panel-heading" style="background-color:#4dd2ff;">
			        <h3 class="panel-title" style="color: black;" ><b>First Audition</b></h3>
			  </div>
			  <div class="panel-body">
			        Our first audition will held on 1/10/2016 venue:Silver Jubliee (Cultural Hall above canteen)
			  </div>
			  <div class="panel-heading" style="background-color:#80dfff;">
			        <h3 class="panel-title" style="color: black;"><b>Play on Women Empowrment </b></h3>
			  </div>
			  <div class="panel-body">
			        The play on women empowerment will take place on 5/10/2016 near Mother teresa mess at 6.00pm
			        <br>
			        Team Members:<br>
			        1. Aman Kumar(Asst. Director)<br>
			        2. Rachna Singh<br>
			        3. Sanjay Kumar(Choreographer)<br>
			        4. Gargee Sarkar<br>
			        5. Gitika <br>
			        6. Poonam Kumari<br>
			        7. Surbhi<br>
			        8. Aman Kumar<br>
			        9. Gaurav Singh Chauhan<br>
			        10. Sanjeev Kumar<br>
			        11. Abhishek Kumar (Director)

			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>2nd Audition</b></h3>
			  </div>
			  <div class="panel-body">
			        Our second audition will held on 8/10/2016 venue:Silver Jubliee (Cultural Hall above canteen)
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Final Audition</b></h3>
			  </div>
			  <div class="panel-body">
			        Date will be announced soon.     
			  </div>
			  
</div>
