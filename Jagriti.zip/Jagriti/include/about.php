<div class="list-group" >
  <a class="list-group-item" style="background-color: #f2e6d9;" >
    <table>
    <th width="10%"><div class="block" >News Flash</div></th>
  <th width="80%" >
   <div style="position: relative; width: 100%; height: 35px;">
   <?php include('include/news.php'); ?>
    </div>
  </th>
  </table>
  </a>
</div>
  
  <!--<table class="table table-striped table-hover ">
  <th width="10%">M.C.A</th>
  <th width="20%">M.Tech (NIE and CSE)</th>
  <th width="10%">M.Sc</th>
  <th width="20%">M.Sc (Int. 5 years)</th>
  <th width="10%">Phd</th>
  </table> 
  </div> -->
