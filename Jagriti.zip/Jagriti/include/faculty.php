
 <div class="panel panel-primary" >
			  <div class="panel-heading" style="background-color: #4db8ff;">
			        <h3 class="panel-title" style="text-align: center;"><b>COMITEE MEMBERS JAGRITI 2016</b></h3>
			  </div>
			  <div class="panel-body">
			        Comitee Members of Diffrent Divisions
			  </div>
			  <div class="panel-heading" style="background-color:#4dd2ff;">
			        <h3 class="panel-title" style="color: black;" ><b>Core Comitee</b></h3>
			  </div>
			  <div class="panel-body">
			        Team Members:<br>
			        1. Aman Kumar ( 9486865902)<br>
			        2. Abhishek Kumar(suraj) (7598433417)<br>
			        3. Sanjay Kumar  (7598643478)<br>
			        4. Ajay Kumar  (9486173486)<br>
			        5. Anshuman <br>
			        6. Ashutosh <br>
			        7. Gaurav Singh Chauhan ( 9442904627)<br>
			        8. Prem Kumar (7598008677)<br>
			        9. Kavi Kumar<br>
			  </div>
			  <div class="panel-heading" style="background-color:#80dfff;">
			        <h3 class="panel-title" style="color: black;"><b>Finance Comitee </b></h3>
			  </div>
			  <div class="panel-body">
			       Team Members:<br>
			        1. Vishal Kumar ()<br>
			        2. Rohit Kumar ()<br>
			        3. Rakesh Kumar  (9489446880)<br>
			        4. Rachna Singh  <br>
			        5. Supriya Kumari <br>
			        6. Manita Kumari <br>
			        7. Gargee Sarkar <br>
			        
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Cultural Comitee</b></h3>
			  </div>
			  <div class="panel-body">
			        Team Members:<br>
			        1. Sanjay Kumar <br>
			        2. Ajay Kumar<br>
			        3. Rachna Singh <br>
			        4. Gitika  <br>
			        5. Gargee Sarkar <br>
			        6. Manita Kumari <br>
			        7. Aman Kumar <br>
			        8. Vivek Kumar <br>
			        9. Anshuman <br>
			        10. Chandan Kumar<br>
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Promotion Comitee</b></h3>
			  </div>
			  <div class="panel-body">
			        Team Members:<br>
			        1. Ajay Kumar <br>
			        2. Ashis Kumar<br>
			        3. Razwan  <br>
			        4. Chandan Kumar  <br>
			        5. Anshuman <br>
			        6. Ashutosh  <br>
			        
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Food Comitee</b></h3>
			  </div>
			  <div class="panel-body">
			        Team Members:<br>
			        1. Kundan Kumar <br>
			        2. Kamakhya Pandey <br>
			        3. Manish <br>
			        4. Abhishek Kumar  <br>
			        5. Kundan <br>
			           
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Mentor and Advisor</b></h3>
			  </div>
			  <div class="panel-body">
			        Team Members:<br>
			        1. Pramod Kumar Meena (Asst. Proff. Hindi Dept.)<br>
			        2. Dr. Nalini J. Thampi (Proff. and Head Dept. of French) <br>
			        3. Sanjay Kumar Singh(PhD Scholar) <br>
			        4. Abhishek Kumar Singh(PhD Scholar)  <br>
			        5. Ram Kishore Singh (PhD Scholar)  <br>
			        6. Naveen Kumar (PhD Scholar)  <br>   
			  </div>
			  
</div>
