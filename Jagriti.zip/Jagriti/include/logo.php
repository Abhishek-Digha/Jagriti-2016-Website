    
	
			<table class="table table-striped table-hover ">
  				<head>
			    	<tr class="" style="background: url(images/diya.jpg);">
			      		<th width="25%"><div class="logo">
			            <img src="images/diya.jpg" alt="logo" style=" height: 4%; width:100%;"/>
	                    </th>
			      		<th width="40%" ><div class="mycss" >जागृति  २०१६</div></th>
			      		<th width="25%"><div class="logo">
			            <img src="images/diya.jpg" alt="logo" style=" height: 4%; width:100%;"/>
			    	</tr>
			    </head>
			</table>
	

<style type="text/css">
.mycss
{
font-weight:normal;color:#ffd633;letter-spacing:0pt;word-spacing:0pt;font-size:60px;text-align:left;font-family:times new roman, times, serif;line-height:1;
}
</style>
