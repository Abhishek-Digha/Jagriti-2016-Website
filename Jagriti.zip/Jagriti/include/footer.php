
     	<div id="footer" style="background: url(images/body-bg.gif); width: 100%"> 
        <div class="panel panel-primary">
		<div class="panel-heading">
		    <h3 class="panel-title" style="text-align: center;"><b>Previous Sponsors</b></h3>
		</div>
     	</div>
        <div class="panel-body">
		    <div class="row">
			  <div class="col-sm-3" ><a href="#" class="btn btn-success">Akshaya Resturant</a></div>
			  <div class="col-sm-3"><a href="#" class="btn btn-info">Punjabi Dhaba</a></div>
			  <div class="col-sm-3"><a href="#" class="btn btn-warning">University Tea Shop</a></div>
			  <div class="col-sm-3"><a href="#" class="btn btn-danger">Student Xerox </a></div>
			</div>
		</div>
		<div class="panel panel-primary">
		<div class="panel-heading">
		    <h3 class="panel-title" style="text-align: center;"><b>Copyright@Abhishek-2016</b></h3>
		</div>
     	</div>
        </div>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/myjs.js"></script>		
		


